package programa;

import java.time.LocalDate;

public class Conta {
    private static int contadorConta = 1;
    private int numeroConta;
    Pessoa pessoa;
    private double saldo=0;

    public Conta(Pessoa pessoa) {
        this.numeroConta = numeroConta;
        this.pessoa = pessoa;
        numeroConta = contadorConta+1;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Conta{" +
                "numeroConta=" + numeroConta +
                ", pessoa=" + pessoa +
                ", saldo=" + saldo +
                '}';
    }

    public void deposita(double valor){
        if(valor > 0)
           setSaldo(getSaldo()+valor);
        System.out.println("Deposito realizado");
        }
    public void sacar(double valor){
        if (this.getSaldo() == 0 && getSaldo() < valor){
            System.out.println("Saldo insuficiente");
        }else{
            double v = getSaldo() - valor;
            setSaldo(v);
            System.out.println("Saque realizado com sucesso "+v);
        }
    }

    public void transfer(double valor,Conta destino){
        if (this.getSaldo() >= valor){
            setSaldo(getSaldo() - valor);
            destino.saldo += getSaldo();
            System.out.println("Transferencia realizada com sucesso "+valor);
        }else{
            System.out.println("Transferencia não realizada "+valor);
        }
    }

    }


package programa;

import utilitarios.Ultios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AgenciaBancaria {
    static Scanner entre  = new Scanner(System.in);

    static List<Conta> contaBancaria;

    public static void main(String[] args) {
        contaBancaria = new ArrayList<>();
        operacoes();
    }

    private static void operacoes() {
        System.out.println("------------------------------------------------------");
        System.out.println("--------------Bem vindos a nossa Agência--------------");
        System.out.println("------------------------------------------------------");
        System.out.println("***** Selecione uma operação que deseja realizar *****");
        System.out.println("------------------------------------------------------");
        System.out.println("| Opcao 1 - Criar conta |");
        System.out.println("| Opcao 2 - Depositar   |");
        System.out.println("| Opcao 3 - Sacar       |");
        System.out.println("| Opcao 4 - Transferir  |");
        System.out.println("| Opcao 5 - Listar      |");
        System.out.println("| Opcao 6 - Sair        |");

        int opcao = entre.nextInt();

        switch (opcao){
            case 1 : criarConta();
            break;
            case 2 : Depositar();
            break;
            case 3 : Sacar();
            break;
            case 4 : Transferir();
            break;
            case 5 : listaContas();
            case 6 : System.exit(0);
            default:
                System.out.println("Opção invalida");
                operacoes();
                break;
        }
    }

    private static void listaContas() {
       if(contaBancaria.size() > 0){
           for (Conta c:contaBancaria) {
               System.out.println(c);
           }
       }else {
           System.out.println("Não existe contas cadastradas");
       }
        operacoes();
    }

    private static void criarConta() {
        System.out.print("Nome: ");
        String nome = entre.next();
        System.out.print("Cpf: ");
        String cpf = entre.next();
        System.out.print("Email: ");
        String email = entre.next();

        Pessoa pessoa = new Pessoa(nome,cpf,email);
        Conta conta = new Conta(pessoa);
        contaBancaria.add(conta);
        System.out.println("Conta criada com sucesso");
        operacoes();
    }

    private static Conta encotraContaBancaria(int numeroConta){
        Conta contas =null;
        if(contaBancaria.size()>0){
            for (Conta c: contaBancaria) {
                if(c.getNumeroConta() == numeroConta){
                    contas = c;                }
            }
        }

        return contas;
    }

    private static void Depositar() {
        System.out.println("Digite o numero da conta");
        int numero = entre.nextInt();
        Conta conta = encotraContaBancaria(numero);
        if (conta.getNumeroConta() == numero){
            System.out.println("QUal o valor para deposito");
            double v = entre.nextDouble();
            conta.deposita((v));

        }else{
            System.out.println("Conta não encontrada");
        }
        operacoes();
    }
    private static void Sacar() {
        System.out.println("Digite o numero da conta");
        int numero = entre.nextInt();
        Conta conta = encotraContaBancaria(numero);
        if (conta.getNumeroConta() != numero){
            System.out.println("Conta não encontrada");
        }else{
            System.out.println("Qual o valor para saque");
            double v = entre.nextDouble();
            conta.sacar((v));
            System.out.println("Saque realizado com sucesso:"+v);
        }
        operacoes();
    }
    private static void Transferir() {
        System.out.println("Digite o numero da conta destino");
        int numeroContaOrigem = entre.nextInt();
        Conta ContaOrigem = encotraContaBancaria(numeroContaOrigem);
        if (ContaOrigem.getNumeroConta() != numeroContaOrigem){
            System.out.println("Conta não encontrada");
        }else{
            System.out.println("Entre com a conta do destinatario: ");
            int contaDestino = entre.nextInt();
            double v = entre.nextDouble();
            Conta contaBancariaDestino = encotraContaBancaria(contaDestino);
            ContaOrigem.transfer(v,contaBancariaDestino);
            System.out.println("Tranferência realizada com sucesso: "+v);
        }
        operacoes();
    }


}
